"""Procedural 2.5D cooking-reel renderer: Pillow + numpy + FFmpeg. No raw footage, no external assets
except Google Fonts (downloaded once). Sound effects and ASMR layers are synthesised in numpy."""
import json
import math
import os
import random
import shutil
import subprocess
import tempfile
import urllib.request
import wave

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

SR = 44100
ASSET_DIR = os.environ.get("ASSET_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets"))
FONT_DIR = os.path.join(ASSET_DIR, "fonts")
GF = "https://github.com/google/fonts/raw/main/ofl/"
FONT_URLS = {
    "Anton-Regular.ttf": GF + "anton/Anton-Regular.ttf",
    "BebasNeue-Regular.ttf": GF + "bebasneue/BebasNeue-Regular.ttf",
    "Montserrat-Variable.ttf": GF + "montserrat/Montserrat%5Bwght%5D.ttf",
}
TTS_VOICE = os.environ.get("TTS_VOICE", "en-US-GuyNeural")
TR_DUR = 0.35


# ----------------------------------------------------------------------------- assets / fonts
def ensure_assets():
    os.makedirs(FONT_DIR, exist_ok=True)
    for name, url in FONT_URLS.items():
        dest = os.path.join(FONT_DIR, name)
        if os.path.exists(dest) and os.path.getsize(dest) > 10000:
            continue
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "reel-renderer"})
            with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
                shutil.copyfileobj(r, f)
            print("downloaded font", name)
        except Exception as e:  # tolerated: DejaVu fallback keeps renders working
            print("font download failed", name, e)


_font_cache = {}
_FILES = {"anton": "Anton-Regular.ttf", "bebas": "BebasNeue-Regular.ttf", "mont": "Montserrat-Variable.ttf"}
_DEJAVU = {
    "mono": ["/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"],
    "other": ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"],
}


def font(kind, size):
    size = max(8, int(size))
    key = (kind, size)
    if key in _font_cache:
        return _font_cache[key]
    f = None
    name = _FILES.get(kind)
    if name:
        p = os.path.join(FONT_DIR, name)
        if os.path.exists(p):
            try:
                f = ImageFont.truetype(p, size)
                if kind == "mont":
                    try:
                        f.set_variation_by_axes([900])  # Montserrat Black
                    except Exception:
                        pass
            except Exception:
                f = None
    if f is None:
        for p in _DEJAVU["mono" if kind == "mono" else "other"]:
            if os.path.exists(p):
                try:
                    f = ImageFont.truetype(p, size)
                    break
                except Exception:
                    pass
    if f is None:
        f = ImageFont.load_default(size)
    _font_cache[key] = f
    return f


# ----------------------------------------------------------------------------- small helpers
def clamp(x, a, b):
    return max(a, min(b, x))


def hex2rgb(h, default=(255, 255, 255)):
    try:
        h = str(h).strip().lstrip("#")
        if len(h) != 6:
            return default
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return default


def smooth(u):
    u = clamp(u, 0.0, 1.0)
    return u * u * (3 - 2 * u)


def spring_scale(lt):
    """0.65 -> 1.18 in 110 ms, then settle to 1.0."""
    if lt < 0:
        return 0.0
    if lt < 0.11:
        u = lt / 0.11
        return 0.65 + 0.53 * (1 - (1 - u) ** 3)
    if lt < 0.20:
        return 1.18 - 0.18 * smooth((lt - 0.11) / 0.09)
    return 1.0


def abs_time(scene, at):
    """Storyboard times may be absolute or relative to the scene; accept both."""
    try:
        at = float(at)
    except Exception:
        return scene["start"]
    return at if at >= scene["start"] - 0.05 else scene["start"] + at


def vgrad(w, h, top, bot):
    t = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
    a = np.array(top, np.float32)[None, None, :]
    b = np.array(bot, np.float32)[None, None, :]
    arr = (a * (1 - t) + b * t) * np.ones((1, w, 1), np.float32)
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB")


def glow(w, h, cx, cy, r, color, k=1.0):
    ys, xs = np.ogrid[:h, :w]
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2) / max(r, 1)
    a = np.clip(1 - d, 0, 1) ** 2 * k
    arr = a[:, :, None] * np.array(color, np.float32)[None, None, :]
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB")


def iso_cube(d, cx, cy, s, top, left, right, outline=(20, 20, 24)):
    d.polygon([(cx, cy - s), (cx + s, cy - s / 2), (cx, cy), (cx - s, cy - s / 2)], fill=top, outline=outline)
    d.polygon([(cx - s, cy - s / 2), (cx, cy), (cx, cy + s), (cx - s, cy + s / 2)], fill=left, outline=outline)
    d.polygon([(cx, cy), (cx + s, cy - s / 2), (cx + s, cy + s / 2), (cx, cy + s)], fill=right, outline=outline)


def shade(c, k):
    return tuple(int(clamp(v * k, 0, 255)) for v in c)


def rot_pts(pts, pivot, deg):
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    out = []
    for x, y in pts:
        dx, dy = x - pivot[0], y - pivot[1]
        out.append((pivot[0] + dx * ca - dy * sa, pivot[1] + dx * sa + dy * ca))
    return out


def find_coeffs(dst, src):
    rows = []
    for (x, y), (u, v) in zip(dst, src):
        rows.append([x, y, 1, 0, 0, 0, -u * x, -u * y])
        rows.append([0, 0, 0, x, y, 1, -v * x, -v * y])
    return np.linalg.solve(np.array(rows, dtype=np.float64), np.array(src, dtype=np.float64).reshape(8))


def perspective(lay, tilt):
    w, h = lay.size
    dl = h * 0.5 * max(tilt, 0)
    dr = h * 0.5 * max(-tilt, 0)
    dst = [(0, dl), (w, dr), (w, h - dr), (0, h - dl)]
    src = [(0, 0), (w, 0), (w, h), (0, h)]
    return lay.transform((w, h), Image.PERSPECTIVE, tuple(find_coeffs(dst, src)), Image.BICUBIC)


def glitch(img, amount, seed):
    rng = np.random.default_rng(seed)
    arr = np.asarray(img).copy()
    h, w, _ = arr.shape
    dx = max(2, int(w * 0.018 * amount))
    arr[:, :, 0] = np.roll(arr[:, :, 0], dx, axis=1)
    arr[:, :, 2] = np.roll(arr[:, :, 2], -dx, axis=1)
    for _ in range(5):
        y0 = int(rng.integers(0, h - 4))
        bh = int(rng.integers(h // 60, h // 14))
        shift = int(rng.integers(-w // 12, w // 12))
        arr[y0:y0 + bh] = np.roll(arr[y0:y0 + bh], shift, axis=1)
    return Image.fromarray(arr)


# ----------------------------------------------------------------------------- audio synthesis
def _noise(n, seed):
    return np.random.default_rng(seed).standard_normal(n).astype(np.float32)


def _lp(x, k):
    k = max(1, int(k))
    return np.convolve(x, np.ones(k, np.float32) / k, mode="same").astype(np.float32)


def _fade(x, ms=40):
    n = min(len(x) // 2, int(SR * ms / 1000))
    if n > 1:
        x[:n] *= np.linspace(0, 1, n, dtype=np.float32)
        x[-n:] *= np.linspace(1, 0, n, dtype=np.float32)
    return x


def sfx_pop():
    n = int(0.12 * SR)
    t = np.arange(n) / SR
    ph = 2 * np.pi * np.cumsum(220 + 600 * np.exp(-t * 30)) / SR
    return (np.sin(ph) * np.exp(-t * 28) * 0.8).astype(np.float32)


def sfx_chop(seed=1):
    n = int(0.14 * SR)
    t = np.arange(n) / SR
    nz = _noise(n, seed)
    y = (nz - _lp(nz, 6)) * np.exp(-t * 55) * 0.9 + np.sin(2 * np.pi * 120 * t) * np.exp(-t * 40) * 0.6
    return y.astype(np.float32)


def sfx_whoosh(dur=0.55):
    n = int(dur * SR)
    t = np.arange(n) / SR
    env = np.sin(np.pi * t / dur) ** 2
    nz = _lp(_noise(n, 7), 18) * 3.0
    chirp = np.sin(2 * np.pi * (200 * t + (1800 / (2 * dur)) * t * t)) * 0.25
    return ((nz * 0.5 + chirp * 0.5) * env).astype(np.float32)


def sfx_bass(dur=1.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    ph = 2 * np.pi * np.cumsum(140 * np.exp(-t * 3) + 30) / SR
    y = np.sin(ph) * np.exp(-t * 2.2)
    y[:int(0.005 * SR)] += _noise(int(0.005 * SR), 3) * 0.5
    return y.astype(np.float32)


def asmr_sizzle(dur, seed=5):
    n = int(dur * SR)
    nz = _noise(n, seed)
    y = (nz - _lp(nz, 3)) * 0.22
    rng = np.random.default_rng(seed + 1)
    for i in rng.integers(0, max(n - 400, 1), int(dur * 40)):
        b = _noise(300, int(i))
        y[i:i + 300] += (b - _lp(b, 3)) * 0.5 * np.exp(-np.arange(300) / 60.0)
    return _fade(y.astype(np.float32), 50)


def asmr_pour(dur, seed=9):
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = _lp(_noise(n, seed), 10) * 2.0 * (0.6 + 0.4 * np.sin(2 * np.pi * 5 * t)) * 0.35
    return _fade(y.astype(np.float32), 80)


def asmr_simmer(dur, seed=11):
    n = int(dur * SR)
    y = _lp(_noise(n, seed), 120) * 0.08
    rng = np.random.default_rng(seed)
    for _ in range(int(dur * 16)):
        i = int(rng.integers(0, max(n - 2300, 1)))
        m = int(0.05 * SR)
        tt = np.arange(m) / SR
        y[i:i + m] += np.sin(2 * np.pi * rng.uniform(220, 640) * tt) * np.exp(-tt * 70) * rng.uniform(0.08, 0.2)
    return _fade(y.astype(np.float32), 80)


def asmr_chops(dur, seed=13):
    n = int(dur * SR)
    y = np.zeros(n, np.float32)
    rng = random.Random(seed)
    t = 0.0
    while t < dur - 0.1:
        _add(y, sfx_chop(rng.randint(1, 999)), t, 1.0)
        t += 0.24 + rng.uniform(-0.03, 0.05)
    return y


def _add(buf, clip, at, gain=1.0):
    i = int(max(0.0, at) * SR)
    if i >= len(buf):
        return
    j = min(len(buf), i + len(clip))
    buf[i:j] += clip[:j - i] * gain


def _decode(src, tempo=None):
    cmd = ["ffmpeg", "-v", "error", "-i", src, "-ar", str(SR), "-ac", "1"]
    if tempo:
        cmd += ["-filter:a", "atempo=%.3f" % tempo]
    cmd += ["-f", "f32le", "-"]
    r = subprocess.run(cmd, capture_output=True, timeout=120)
    return np.frombuffer(r.stdout, np.float32).copy()


def tts_clip(text, workdir, idx, window):
    mp3 = os.path.join(workdir, "v%d.mp3" % idx)
    wav = os.path.join(workdir, "v%d.wav" % idx)
    src = None
    try:
        r = subprocess.run(["edge-tts", "--voice", TTS_VOICE, "--rate=+12%", "--text", text, "--write-media", mp3],
                           capture_output=True, timeout=90)
        if r.returncode == 0 and os.path.exists(mp3) and os.path.getsize(mp3) > 1000:
            src = mp3
    except Exception as e:
        print("edge-tts failed:", e)
    if src is None:
        try:
            r = subprocess.run(["espeak-ng", "-v", "en-us+f3", "-s", "172", "-w", wav, text], capture_output=True, timeout=60)
            if r.returncode == 0 and os.path.exists(wav):
                src = wav
        except Exception as e:
            print("espeak-ng failed:", e)
    if src is None:
        return None
    y = _decode(src)
    if window > 0.4 and len(y) / SR > window * 1.02:
        y = _decode(src, tempo=min(1.45, len(y) / SR / window))
    return y


def build_audio(spec, scenes, duration, workdir, out_wav):
    n = int(duration * SR) + SR
    voice = np.zeros(n, np.float32)
    asmr = np.zeros(n, np.float32)
    sfx = np.zeros(n, np.float32)
    sb = spec.get("storyboard") or {}
    for i, v in enumerate(sb.get("voiceover") or []):
        line = str(v.get("line") or " ".join(str(w.get("w", "")) for w in v.get("words", []))).strip()
        if not line:
            continue
        st = float(v.get("start", 0) or 0)
        win = float(v.get("end", st + 4) or st + 4) - st
        clip = tts_clip(line, workdir, i, win)
        if clip is not None and len(clip):
            _add(voice, clip, st, 1.0)
    lib = {"pop": sfx_pop(), "chop": sfx_chop(), "whoosh": sfx_whoosh(), "bass_drop": sfx_bass()}
    cue_sfx = {"voxel_chef_react": "pop", "pixel_dissolve": "whoosh", "3d_text_arc": "pop", "whip_pan": "whoosh",
               "camera_shake": "bass_drop", "glitch_rgb_split": "bass_drop", "zoom_through": "whoosh",
               "ingredient_pop": "pop", "steam_rise": "whoosh"}
    for sc in scenes:
        for a in sc.get("asmr") or []:
            at = abs_time(sc, a.get("at"))
            dur = clamp(float(a.get("dur", 1.5) or 1.5), 0.3, 12.0)
            g = 10 ** (clamp(float(a.get("gain_db", 0) or 0), -30, 6) / 20)
            layer = str(a.get("layer", "")).lower()
            if "chop" in layer:
                clip = asmr_chops(dur)
            elif "sizzle" in layer or "oil" in layer:
                clip = asmr_sizzle(dur)
            elif "pour" in layer or "liquid" in layer:
                clip = asmr_pour(dur)
            else:
                clip = asmr_simmer(dur)
            _add(asmr, clip, at, g)
        for s in sc.get("sfx") or []:
            name = str(s.get("sfx", "pop")).replace(".mp3", "")
            if name == "sizzle":
                _add(asmr, asmr_sizzle(0.9), abs_time(sc, s.get("at")), 1.2)
            else:
                _add(sfx, lib.get(name, lib["pop"]), abs_time(sc, s.get("at")), 0.8)
        for c in sc.get("animation_cues") or []:
            cue = str(c.get("cue", ""))
            at = abs_time(sc, c.get("at"))
            if cue == "knife_chop":
                _add(asmr, asmr_chops(1.0), at, 1.3)   # boost ASMR on action beats
            elif cue == "oil_sizzle":
                _add(asmr, asmr_sizzle(1.5), at, 1.3)
    env = _lp(np.abs(voice), int(0.06 * SR))
    duck = 1 - 0.6 * np.clip(env * 25, 0, 1)
    mix = voice + asmr * duck * 0.9 + sfx * 0.8
    peak = float(np.max(np.abs(mix))) + 1e-6
    if peak > 0.89:
        mix *= 0.89 / peak
    pcm = (np.clip(mix[:int(duration * SR)], -1, 1) * 32767).astype(np.int16)
    with wave.open(out_wav, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


# ----------------------------------------------------------------------------- visuals
class Reel:
    def __init__(self, spec):
        proj = spec.get("project") or {}
        self.W = int(proj.get("width", 1080))
        self.H = int(proj.get("height", 1920))
        self.fps = int(proj.get("fps", 60))
        self.dur = float(proj.get("duration", 50))
        self.S = self.W / 1080.0
        self.spec = spec
        self.sb = spec.get("storyboard") or {}
        theme = spec.get("theme") or {}
        self.theme = theme
        self.tid = str(theme.get("id", "A")).upper()
        pal = theme.get("palette") or {}
        self.bgc = hex2rgb(pal.get("bg", "#12100E"), (18, 16, 14))
        self.accent = hex2rgb(pal.get("accent", "#FFB347"), (255, 179, 71))
        typ = spec.get("typography") or {}
        self.hl = [hex2rgb(c) for c in (typ.get("highlightColors") or ["#FF2A2A", "#FFD700", "#00FF9D"])] or [(255, 215, 0)]
        self.seed = int(spec.get("seed") or 1)
        self.margin_y = int(180 * self.S)
        self.margin_x = int(90 * self.S)
        self._bg = {}
        self.scenes = self._prep_scenes()
        self.voice_words = []
        for v in self.sb.get("voiceover") or []:
            for w in v.get("words") or []:
                try:
                    self.voice_words.append((float(w["t0"]), float(w["t1"]), str(w.get("w", "")), bool(w.get("emphasis")), w.get("color")))
                except Exception:
                    pass
        self.ingredients = [str(i.get("name", "")) for i in (self.sb.get("ingredients") or []) if isinstance(i, dict)][:5]

    def _prep_scenes(self):
        raw = [s for s in (self.sb.get("scenes") or []) if isinstance(s, dict)]
        if not raw:
            raw = [{"id": 1, "start": 0, "end": self.dur}]
        n = len(raw)
        out = []
        for i, s in enumerate(raw):
            s = dict(s)
            st = float(s.get("start", i * self.dur / n) or 0)
            en = float(s.get("end", (i + 1) * self.dur / n) or 0)
            if en <= st:
                en = st + self.dur / n
            s["start"], s["end"], s["_i"] = st, en, i
            if i == 0 and not s.get("text_overlays") and self.sb.get("hook"):
                s["text_overlays"] = [{"text": self.sb["hook"], "style": "arc", "at": 0.1, "dur": 2.6}]
            s["_shake"], s["_glitch"] = [], []
            for c in s.get("animation_cues") or []:
                at = abs_time(s, c.get("at"))
                if c.get("cue") == "camera_shake":
                    s["_shake"].append(at)
                if c.get("cue") == "glitch_rgb_split":
                    s["_glitch"].append(at)
                    s["_shake"].append(at)
            for x in s.get("sfx") or []:
                if x.get("sfx") in ("bass_drop", "chop"):
                    s["_shake"].append(abs_time(s, x.get("at")))
            blob = json.dumps(s).lower()
            if any(k in blob for k in ("chop", "knife", "slice", "dice")):
                s["_prop"] = "chop"
            elif any(k in blob for k in ("boil", "simmer", "soup", "stew", "pot")):
                s["_prop"] = "pot"
            elif any(k in blob for k in ("sizzle", "pan", "fry", "sear", "toss")):
                s["_prop"] = "pan"
            else:
                s["_prop"] = ("pan", "chop", "pot")[i % 3]
            out.append(s)
        out.sort(key=lambda s: s["start"])
        for i, s in enumerate(out):
            s["_i"] = i
        return out

    def scene_at(self, t):
        for i, s in enumerate(self.scenes):
            if t < s["end"]:
                return i
        return len(self.scenes) - 1

    # ---------------------------------------------------------------- backgrounds (cached per scene)
    def background(self, sc):
        i = sc["_i"]
        if i in self._bg:
            return self._bg[i]
        W, H, S = self.W, self.H, self.S
        rnd = random.Random(self.seed + i * 31)
        if self.tid == "B":
            img = vgrad(W, H, (126, 200, 255), (217, 240, 255))
            d = ImageDraw.Draw(img)
            for _ in range(4):
                cx, cy = rnd.randint(0, W), rnd.randint(int(H * .08), int(H * .3))
                for k in range(4):
                    d.ellipse((cx + k * 70 * S - 90 * S, cy - 40 * S, cx + k * 70 * S + 90 * S, cy + 40 * S), fill=(255, 255, 255))
            d.rectangle((W * .12, H * .06, W * .88, H * .42), outline=(250, 250, 250), width=max(4, int(16 * S)))
            d.line((W * .5, H * .06, W * .5, H * .42), fill=(250, 250, 250), width=max(3, int(12 * S)))
            d.rectangle((0, H * .62, W, H), fill=(169, 119, 74))
            for _ in range(40):
                y = rnd.randint(int(H * .62), H)
                d.line((0, y, W, y + rnd.randint(-6, 6)), fill=(140, 95, 58), width=max(1, int(3 * S)))
            d.polygon([(W * .2 + 40 * S, H * .66 + 28 * S), (W * .8 + 40 * S, H * .66 + 28 * S), (W * .8 + 60 * S, H * .84 + 28 * S), (W * .2 + 60 * S, H * .84 + 28 * S)], fill=(90, 60, 35))
            d.rectangle((W * .2, H * .66, W * .8, H * .84), fill=(205, 150, 95), outline=(120, 80, 45), width=max(3, int(8 * S)))
            img = ImageChops.add(img, glow(W, H, int(W * (.35 + .3 * rnd.random())), int(H * .2), int(W * .9), (255, 240, 200), .35))
        elif self.tid == "C":
            img = vgrad(W, H, shade(self.bgc, 1.4), shade(self.bgc, .5))
            d = ImageDraw.Draw(img)
            tile = int(110 * S)
            for k in range(-20, 21):
                x0 = W / 2 + k * tile * 2
                d.line([(x0, H * .5), (x0 + W, H * .5 + W * .5)], fill=shade(self.bgc, 2.0), width=max(1, int(2 * S)))
                d.line([(x0, H * .5), (x0 - W, H * .5 + W * .5)], fill=shade(self.bgc, 2.0), width=max(1, int(2 * S)))
            s = int(90 * S)
            for gx in range(3):
                for gy in range(2):
                    iso_cube(d, W * .30 + gx * s + gy * 0, H * .70 + gy * s * .9 - gx * 0, s, (150, 150, 160), (110, 110, 120), (85, 85, 95))
            iso_cube(d, W * .30 + s, H * .70 - s * 1.2, s, (255, 160, 60), (230, 110, 30), (200, 80, 20))
            img = ImageChops.add(img, glow(W, H, int(W * .38), int(H * .62), int(W * .6), self.accent, .35))
        elif self.tid == "D":
            img = vgrad(W, H, (24, 24, 26), (12, 12, 14))
            d = ImageDraw.Draw(img)
            d.polygon([(0, H * .20), (W, H * .05), (W, H * .17), (0, H * .33)], fill=shade(self.accent, .7))
            d.polygon([(0, H * .82), (W, H * .70), (W, H * .78), (0, H * .90)], fill=shade(self.accent, .55))
            img = ImageChops.add(img, glow(W, H, W // 2, 0, int(H * .9), (255, 235, 220), .5))
            d = ImageDraw.Draw(img)
            d.rectangle((0, H * .62, W, H), fill=(28, 28, 30))
        else:  # A: cozy midnight kitchen
            img = vgrad(W, H, shade(self.bgc, 1.3), shade(self.bgc, .6))
            d = ImageDraw.Draw(img)
            tile = int(120 * S)
            for r in range(int(H * .62 / tile) + 1):
                for c in range(W // tile + 1):
                    sh = rnd.randint(-6, 6)
                    d.rectangle((c * tile, r * tile, (c + 1) * tile, (r + 1) * tile), fill=(43 + sh, 47 + sh, 54 + sh), outline=(18, 18, 22), width=max(2, int(3 * S)))
            d.rectangle((0, H * .66, W, H), fill=(52, 36, 24))
            d.line((0, H * .66, W, H * .66), fill=(95, 70, 45), width=max(3, int(8 * S)))
            for bx in (.3, .7):
                d.ellipse((W * bx - 150 * S, H * .70 - 40 * S, W * bx + 150 * S, H * .70 + 40 * S), fill=(20, 20, 22), outline=(60, 60, 64), width=max(2, int(6 * S)))
            img = ImageChops.add(img, glow(W, H, int(W * (.2 + .6 * rnd.random())), int(H * .08), int(W * .9), (255, 170, 60), .55))
            img = ImageChops.add(img, glow(W, H, int(W * .5), int(H * .70), int(W * .5), (255, 90, 20), .3))
        cam = sc.get("camera") or {}
        if cam.get("dof_blur"):
            img = img.filter(ImageFilter.GaussianBlur(max(2, 14 * S)))  # depth of field: props stay sharp on top
        self._bg[i] = img
        return img

    # ---------------------------------------------------------------- animated layers
    def _overlay(self):
        q = 4
        ov = Image.new("RGBA", (self.W // q, self.H // q), (0, 0, 0, 0))
        return ov, ImageDraw.Draw(ov), q

    def _paste_overlay(self, img, ov):
        big = ov.resize((self.W, self.H), Image.BILINEAR)
        img.paste(big, (0, 0), big)

    def anim_theme(self, img, d, t, sc):
        W, H, S = self.W, self.H, self.S
        if self.tid in ("A", "B", "D"):
            ov, od, q = self._overlay()
            w, h = ov.size
            if self.tid == "D":
                bx = (0.5 + 0.35 * math.sin(t * 0.7)) * w
                od.polygon([(w * .5, 0), (bx - w * .18, h * .7), (bx + w * .18, h * .7)], fill=(255, 240, 220, 38))
            else:
                col = (255, 255, 255) if self.tid == "A" else (255, 255, 255)
                for k in range(12):
                    ph = (t * 0.22 + k / 12.0) % 1.0
                    cx = (0.25 + 0.5 * ((k * 37) % 100) / 100.0) * w + math.sin(t * 1.3 + k) * 30 * S / q
                    cy = 0.66 * h - ph * 0.42 * h
                    r = (30 + ph * 70) * S / q
                    a = int((90 if self.tid == "A" else 60) * (1 - ph) * (ph ** 0.3))
                    od.ellipse((cx - r, cy - r, cx + r, cy + r), fill=col + (a,))
            self._paste_overlay(img, ov)
        if self.tid == "A":
            for bx in (.3, .7):
                for j in range(6):
                    fh = (34 + 16 * math.sin(t * 13 + j * 2.1)) * S
                    x = W * bx + (j - 2.5) * 40 * S
                    y = H * .70
                    d.ellipse((x - 12 * S, y - fh, x + 12 * S, y + 10 * S), fill=(255, 150 + 12 * j, 40))
        if self.tid == "B":
            for k in range(36):
                x = (k * 97.3 + t * 20 * (1 + k % 3)) % W
                y = H * .2 + (k * 53.1) % (H * .45) + math.sin(t * 2 + k) * 20 * S
                r = (3 + k % 4) * S
                d.ellipse((x - r, y - r, x + r, y + r), fill=((205, 160, 90), (190, 60, 40), (90, 150, 70))[k % 3])
        if self.tid == "C":
            for k in range(8):
                x = W * (.12 + .76 * ((k * 0.37) % 1))
                y = H * (.14 + .42 * ((k * 0.23) % 1)) + math.sin(t * 1.6 + k) * 26 * S
                base = shade(self.accent, .8 + .08 * (k % 4))
                iso_cube(d, x, y, 34 * S, base, shade(base, .75), shade(base, .55))
        if self.tid == "D":
            card_y = H * .64
            d.rounded_rectangle((W * .08, card_y, W * .92, card_y + 120 * S), radius=int(18 * S), fill=(30, 30, 34), outline=self.accent, width=max(2, int(4 * S)))
            names = self.ingredients or ["INGREDIENT 1", "INGREDIENT 2", "INGREDIENT 3"]
            p = clamp((t - sc["start"]) / max(sc["end"] - sc["start"], 0.1), 0, 1)
            f = font("mono", 30 * S)
            for j, nm in enumerate(names[:3]):
                cnt = int(p * (j + 2) * 3) + 1
                d.text((W * .12, card_y + (14 + j * 34) * S), "%02d  %s" % (cnt, nm.upper()[:24]), font=f, fill=(240, 240, 240))

    def prop(self, d, t, sc, px):
        S, W, H = self.S, self.W, self.H
        cx, cy = W * .34 + px, H * .56
        kind = sc["_prop"]
        if kind == "chop":
            d.rectangle((cx - 230 * S, cy + 20 * S, cx + 230 * S, cy + 150 * S), fill=(205, 150, 95), outline=(120, 80, 45), width=max(3, int(6 * S)))
            for j in range(6):
                pop = max(0.0, math.sin(t * 9 + j)) * 30 * S
                x = cx - 190 * S + j * 70 * S
                d.rounded_rectangle((x, cy + 40 * S - pop, x + 52 * S, cy + 82 * S - pop), radius=int(8 * S), fill=(232, 130, 40), outline=(150, 70, 20), width=max(2, int(3 * S)))
            ang = abs(math.sin(t * 9)) * 38
            pivot = (cx + 200 * S, cy - 130 * S)
            blade = [(pivot[0] - 330 * S, pivot[1] + 20 * S), (pivot[0], pivot[1]), (pivot[0], pivot[1] + 80 * S), (pivot[0] - 330 * S, pivot[1] + 120 * S)]
            d.polygon(rot_pts(blade, pivot, ang), fill=(205, 210, 218), outline=(70, 70, 76))
            hdl = [(pivot[0], pivot[1] - 8 * S), (pivot[0] + 130 * S, pivot[1] - 4 * S), (pivot[0] + 130 * S, pivot[1] + 44 * S), (pivot[0], pivot[1] + 48 * S)]
            d.polygon(rot_pts(hdl, pivot, ang), fill=(40, 30, 28))
        elif kind == "pot":
            d.rounded_rectangle((cx - 190 * S, cy - 40 * S, cx + 190 * S, cy + 150 * S), radius=int(30 * S), fill=(110, 115, 125), outline=(40, 40, 46), width=max(3, int(6 * S)))
            d.ellipse((cx - 175 * S, cy - 70 * S, cx + 175 * S, cy - 5 * S), fill=(200, 60, 40), outline=(40, 40, 46), width=max(2, int(5 * S)))
            for j in range(8):
                ph = (t * 0.9 + j * 0.13) % 1
                x = cx - 130 * S + ((j * 37) % 260) * S
                y = cy - 40 * S - ph * 90 * S
                r = (10 + 10 * ph) * S
                d.ellipse((x - r, y - r, x + r, y + r), fill=(255, 200, 150), outline=(200, 100, 70))
        else:  # pan
            d.ellipse((cx - 200 * S, cy - 45 * S, cx + 200 * S, cy + 45 * S), fill=(35, 35, 38), outline=(10, 10, 10), width=max(3, int(6 * S)))
            d.ellipse((cx - 170 * S, cy - 32 * S, cx + 170 * S, cy + 28 * S), fill=(58, 58, 62))
            d.polygon([(cx + 190 * S, cy - 14 * S), (cx + 420 * S, cy - 30 * S), (cx + 420 * S, cy), (cx + 190 * S, cy + 16 * S)], fill=(25, 25, 27))
            cols = [(224, 120, 40), (200, 80, 30), (240, 170, 60), (180, 60, 25)]
            for j in range(4):
                ph = (t * 1.3 + j * .27) % 1
                hh = math.sin(math.pi * ph) * 220 * S
                x = cx - 120 * S + j * 80 * S
                r = 34 * S
                d.ellipse((x - r, cy - 20 * S - hh - r, x + r, cy - 20 * S - hh + r), fill=cols[j], outline=(110, 50, 20), width=max(2, int(3 * S)))
            rng = random.Random(int(t * 20))
            for _ in range(10):
                x, y = cx + rng.uniform(-170, 170) * S, cy - rng.uniform(10, 120) * S
                d.ellipse((x - 4 * S, y - 4 * S, x + 4 * S, y + 4 * S), fill=(255, 220, 90))

    def speaking(self, t):
        for a, b, *_ in self.voice_words:
            if a <= t < b:
                return True
        return False

    def chef(self, d, t, sc, cx, cy):
        u = self.S
        react = 0.0
        for c in sc.get("animation_cues") or []:
            if c.get("cue") == "voxel_chef_react":
                dt = t - abs_time(sc, c.get("at"))
                if 0 <= dt < 0.5:
                    react = max(react, math.sin(math.pi * dt / 0.5))
        y = cy + math.sin(t * 4.2) * 8 * u - react * 90 * u
        blocky = self.tid == "C"
        ol = (25, 25, 28)
        wd = max(3, int(5 * u))
        skin = (255, 213, 170)
        arm_y = y + 60 * u - react * 80 * u
        for sx in (-1, 1):
            hx, hy = cx + sx * 150 * u, arm_y + (20 * u if sx == 1 else 0) + math.sin(t * 5 + sx) * 12 * u
            d.line((cx + sx * 80 * u, y + 40 * u, hx, hy), fill=(245, 245, 245), width=int(30 * u))
            d.ellipse((hx - 22 * u, hy - 22 * u, hx + 22 * u, hy + 22 * u), fill=skin, outline=ol, width=wd)
        if blocky:
            d.rectangle((cx - 85 * u, y, cx + 85 * u, y + 190 * u), fill=(245, 245, 245), outline=ol, width=wd)
            d.rectangle((cx + 45 * u, y, cx + 85 * u, y + 190 * u), fill=(205, 205, 210))
            d.rectangle((cx - 80 * u, y - 170 * u, cx + 80 * u, y - 10 * u), fill=skin, outline=ol, width=wd)
            d.rectangle((cx - 85 * u, y - 215 * u, cx + 85 * u, y - 160 * u), fill=(250, 250, 250), outline=ol, width=wd)
            d.rectangle((cx - 70 * u, y - 300 * u, cx + 70 * u, y - 215 * u), fill=(255, 255, 255), outline=ol, width=wd)
        else:
            d.rounded_rectangle((cx - 85 * u, y, cx + 85 * u, y + 190 * u), radius=int(36 * u), fill=(245, 245, 245), outline=ol, width=wd)
            d.ellipse((cx - 80 * u, y - 170 * u, cx + 80 * u, y - 10 * u), fill=skin, outline=ol, width=wd)
            d.rounded_rectangle((cx - 85 * u, y - 215 * u, cx + 85 * u, y - 150 * u), radius=int(14 * u), fill=(250, 250, 250), outline=ol, width=wd)
            for ex, ey, er in ((-70, -300, 55), (-10, -330, 62), (50, -300, 55)):
                d.ellipse((cx + (ex - er) * u, y + (ey - 10) * u, cx + (ex + er) * u, y + (ey + 2 * er - 10) * u), fill=(255, 255, 255), outline=ol, width=wd)
        d.ellipse((cx - 8 * u, y + 40 * u, cx + 8 * u, y + 56 * u), fill=(190, 190, 195))
        er = (10 + 5 * react) * u
        for ex in (-32, 32):
            d.ellipse((cx + ex * u - er, y - 100 * u - er, cx + ex * u + er, y - 100 * u + er), fill=(20, 20, 20))
        d.ellipse((cx - 62 * u, y - 70 * u, cx - 42 * u, y - 54 * u), fill=(255, 150, 140))
        d.ellipse((cx + 42 * u, y - 70 * u, cx + 62 * u, y - 54 * u), fill=(255, 150, 140))
        if react > 0.2 or (self.speaking(t) and int(t * 10) % 2 == 0):
            d.ellipse((cx - 22 * u, y - 62 * u, cx + 22 * u, y - 28 * u), fill=(120, 20, 30), outline=ol, width=max(2, int(3 * u)))
        else:
            d.arc((cx - 30 * u, y - 80 * u, cx + 30 * u, y - 35 * u), 20, 160, fill=ol, width=max(3, int(6 * u)))

    def shake(self, sc, t):
        for e in sc["_shake"]:
            dt = t - e
            win = 2.5 / self.fps
            if 0 <= dt < win:
                a = 22 * self.S * (1 - dt / win)
                rng = random.Random(int(t * self.fps) * 13 + sc["_i"])
                return rng.uniform(-a, a), rng.uniform(-a, a)
        return 0.0, 0.0

    def camera(self, img, sc, t, p):
        cam = sc.get("camera") or {}
        try:
            z0, z1 = float(cam.get("from", 1.0)), float(cam.get("to", 1.12))
        except Exception:
            z0, z1 = 1.0, 1.12
        z = clamp((z0 + (z1 - z0) * p) * 1.06, 1.06, 2.0)  # never static: always zoomed in enough to drift
        cw, ch = self.W / z, self.H / z
        mx, my = (self.W - cw) / 2, (self.H - ch) / 2
        ph = 2 * math.pi * (p * 0.8 + sc["_i"] * 0.37)
        amp = 0.95 if "orbit" in str(cam.get("move", "")).lower() else 0.7
        sx, sy = self.shake(sc, t)
        l = clamp(mx + math.sin(ph) * mx * amp + sx, 0, self.W - cw)
        tp = clamp(my + math.cos(ph * 0.8) * my * amp + sy, 0, self.H - ch)
        return img.resize((self.W, self.H), Image.BILINEAR, box=(l, tp, l + cw, tp + ch))

    def world(self, sc, t):
        p = clamp((t - sc["start"]) / max(sc["end"] - sc["start"], 1e-3), 0, 1)
        img = self.background(sc).copy()
        d = ImageDraw.Draw(img)
        self.anim_theme(img, d, t, sc)
        d = ImageDraw.Draw(img)
        px = math.sin(t * 0.7) * 26 * self.S  # parallax: foreground props drift more than the backdrop
        self.prop(d, t, sc, px)
        self.chef(d, t, sc, self.W * .76 - px * .6, self.H * .50)
        return self.camera(img, sc, t, p)

    # ---------------------------------------------------------------- transitions
    def pick_transition(self, sc):
        for c in sc.get("animation_cues") or []:
            if c.get("cue") in ("whip_pan", "pixel_dissolve", "zoom_through", "glitch_rgb_split"):
                return c["cue"]
        pre = str(self.theme.get("transitionPreset", "")).lower()
        toks = []
        for key, name in (("whip", "whip_pan"), ("pixel", "pixel_dissolve"), ("zoom", "zoom_through"), ("glitch", "glitch_rgb_split")):
            if key in pre:
                toks.append(name)
        toks = toks or ["whip_pan", "pixel_dissolve", "zoom_through", "glitch_rgb_split"]
        return toks[sc["_i"] % len(toks)]

    def transition(self, a, b, u, sc):
        kind = self.pick_transition(sc)
        W, H = a.size
        if kind == "whip_pan":
            off = int(smooth(u) * W)
            combo = Image.new("RGB", (W * 2, H))
            combo.paste(a, (0, 0))
            combo.paste(b, (W, 0))
            blur = int(W * 0.18 * math.sin(math.pi * u))
            if blur < 4:
                return combo.crop((off, 0, off + W, H))
            taps = 7
            acc = np.zeros((H, W, 3), np.float32)
            for k in range(taps):
                o = int(clamp(off + (k / (taps - 1) - 0.5) * blur, 0, W))
                acc += np.asarray(combo.crop((o, 0, o + W, H)), np.float32)
            return Image.fromarray((acc / taps).astype(np.uint8))
        if kind == "pixel_dissolve":
            blk = max(8, int(W / 18))
            gw, gh = (W + blk - 1) // blk, (H + blk - 1) // blk
            thr = np.random.default_rng(self.seed + sc["_i"]).random((gh, gw))
            mask = np.kron((thr < u * 1.15).astype(np.uint8), np.ones((blk, blk), np.uint8))[:H, :W]
            pa = a.resize((gw, gh), Image.BILINEAR).resize((W, H), Image.NEAREST) if u > 0.1 else a
            pb = b.resize((gw, gh), Image.BILINEAR).resize((W, H), Image.NEAREST) if u < 0.9 else b
            return Image.fromarray(np.where(mask[:, :, None] == 1, np.asarray(pb), np.asarray(pa)))
        if kind == "zoom_through":
            e = smooth(u)
            z = 1 + 2.2 * e
            ca = a.resize((W, H), Image.BILINEAR, box=(W / 2 - W / (2 * z), H / 2 - H / (2 * z), W / 2 + W / (2 * z), H / 2 + H / (2 * z)))
            zb = 0.55 + 0.45 * e
            small = b.resize((max(2, int(W * zb)), max(2, int(H * zb))), Image.BILINEAR)
            canvas = ca.copy()
            canvas.paste(small, ((W - small.width) // 2, (H - small.height) // 2))
            return Image.blend(ca, canvas, min(1.0, e * 1.4))
        base = b if u > 0.5 else a
        return glitch(base, 1.0, self.seed + int(u * 100))

    # ---------------------------------------------------------------- kinetic typography
    @staticmethod
    def _wrap(text, f, maxw, stroke):
        lines, cur = [], ""
        for w in text.split():
            trial = (cur + " " + w).strip()
            if f.getlength(trial) + 2 * stroke <= maxw or not cur:
                cur = trial
            else:
                lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines

    def _text_layer(self, text, kind, size, fill, style, lt, maxw):
        S = self.S
        stroke = max(3, int(5 * S))
        pad = int(24 * S)
        dm = ImageDraw.Draw(Image.new("L", (4, 4)))
        if "arc" in style:
            f = font(kind, size)
            while f.getlength(text) > maxw * 0.9 and size > 40 * S:
                size *= 0.92
                f = font(kind, size)
            tw = f.getlength(text)
            R = max(tw * 0.9, 200 * S)
            lh = int(size * 1.3)
            amax = tw / 2 / R
            hgt = int(R * (1 - math.cos(amax))) + lh + 2 * pad
            canvas = Image.new("RGBA", (int(tw + 2 * pad + lh), hgt), (0, 0, 0, 0))
            cum = 0.0
            for ch in text:
                cw = f.getlength(ch)
                a = (cum + cw / 2 - tw / 2) / R
                cum += cw
                if ch == " ":
                    continue
                cl = Image.new("RGBA", (int(cw + 2 * pad), lh + 2 * pad), (0, 0, 0, 0))
                cd = ImageDraw.Draw(cl)
                cd.text((pad + cw / 2 + stroke, pad + lh / 2 + stroke), ch, font=f, fill=(0, 0, 0, 170), anchor="mm", stroke_width=stroke, stroke_fill=(0, 0, 0, 170))
                cd.text((pad + cw / 2, pad + lh / 2), ch, font=f, fill=fill + (255,), anchor="mm", stroke_width=stroke, stroke_fill=(0, 0, 0, 255))
                cl = cl.rotate(-math.degrees(a), resample=Image.BICUBIC, expand=True)
                x = canvas.width / 2 + R * math.sin(a) - cl.width / 2
                y = pad + R * (1 - math.cos(a)) - (cl.height - lh) / 2
                canvas.alpha_composite(cl, (int(clamp(x, 0, canvas.width - cl.width)), int(clamp(y, 0, canvas.height - cl.height))))
            return canvas
        f = font(kind, size)
        lines = self._wrap(text, f, maxw, stroke)
        while (len(lines) > 3 or any(f.getlength(l) + 2 * stroke > maxw for l in lines)) and size > 40 * S:
            size *= 0.9
            f = font(kind, size)
            lines = self._wrap(text, f, maxw, stroke)
        txt = "\n".join(lines)
        sp = int(size * 0.06)
        bb = dm.multiline_textbbox((0, 0), txt, font=f, stroke_width=stroke, align="center", spacing=sp)
        w, h = int(bb[2] - bb[0] + 2 * pad), int(bb[3] - bb[1] + 2 * pad)
        lay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        dd = ImageDraw.Draw(lay)
        pos = (pad - bb[0], pad - bb[1])
        dd.multiline_text((pos[0] + stroke, pos[1] + stroke), txt, font=f, fill=(0, 0, 0, 170), align="center", spacing=sp, stroke_width=stroke, stroke_fill=(0, 0, 0, 170))
        dd.multiline_text(pos, txt, font=f, fill=fill + (255,), align="center", spacing=sp, stroke_width=stroke, stroke_fill=(0, 0, 0, 255))
        if "rise" in style:
            r = smooth(lt / 0.28)
            out = Image.new("RGBA", lay.size, (0, 0, 0, 0))
            out.paste(lay, (0, int((1 - r) * h)))  # emerges from behind the object below it
            return out
        tilt = 0.30 if "recede" in style else 0.14 * math.sin(2 * math.pi * lt * 0.6)
        return perspective(lay, tilt)

    def overlay(self, img, ov, sc, t, order):
        if not isinstance(ov, dict):
            return
        start = abs_time(sc, ov.get("at"))
        try:
            dur = float(ov.get("dur") or 2.2)
        except Exception:
            dur = 2.2
        lt = t - start
        text = str(ov.get("text", "")).strip()
        if lt < 0 or lt > dur or not text:
            return
        S = self.S
        style = str(ov.get("style", "")).lower()
        if any(k in style for k in ("ui", "counter", "step", "tag")):
            kind = "mono"
        elif "bebas" in style:
            kind = "bebas"
        elif "mont" in style:
            kind = "mont"
        else:
            kind = "anton"
        text = text.upper() if kind != "mono" else text
        explicit = ov.get("color")
        fill = hex2rgb(explicit) if explicit else ((255, 255, 255) if lt > 0.3 else self.hl[order % len(self.hl)])
        size = (170 if len(text) <= 12 else 140 if len(text) <= 24 else 110) * S
        lay = self._text_layer(text, kind, size, fill, style, lt, self.W - 2 * self.margin_x)
        sc_f = spring_scale(lt)
        if lt > dur - 0.15:
            sc_f *= clamp((dur - lt) / 0.15, 0.2, 1.0)
        if sc_f != 1.0:
            lay = lay.resize((max(2, int(lay.width * sc_f)), max(2, int(lay.height * sc_f))), Image.BILINEAR)
        lay = lay.rotate(2.5 * math.sin(lt * 3 + order), resample=Image.BICUBIC, expand=True)
        cy = (0.25, 0.47, 0.36)[order % 3] * self.H
        cy = clamp(cy, self.margin_y + lay.height / 2, self.H - self.margin_y - lay.height / 2)
        cx = clamp(self.W / 2 + math.sin(lt * 2) * 12 * S, self.margin_x + lay.width / 2, self.W - self.margin_x - lay.width / 2)
        img.paste(lay, (int(cx - lay.width / 2), int(cy - lay.height / 2)), lay)

    def caption(self, img, t):
        if not self.voice_words:
            return
        k = None
        for i, w in enumerate(self.voice_words):
            if w[0] <= t < w[1] + 0.12:
                k = i
        if k is None:
            return
        S = self.S
        g0 = (k // 3) * 3
        group = self.voice_words[g0:g0 + 3]
        size = 96 * S
        stroke = max(3, int(5 * S))
        parts, total = [], 0
        gap = int(26 * S)
        for gi, (a, b, wt, emph, col) in enumerate(group):
            active = (g0 + gi) == k
            f = font("mont", size)
            fill = (hex2rgb(col) if col else self.hl[(g0 + gi) % len(self.hl)]) if active else (255, 255, 255)
            sf = spring_scale(t - a) if active else 1.0
            sf = sf or 1.0
            word = wt.upper()
            wd, ht = int(f.getlength(word) + 2 * stroke + 20 * S), int(size * 1.5)
            lay = Image.new("RGBA", (wd, ht), (0, 0, 0, 0))
            dd = ImageDraw.Draw(lay)
            dd.text((wd / 2 + stroke, ht / 2 + stroke), word, font=f, fill=(0, 0, 0, 170), anchor="mm", stroke_width=stroke, stroke_fill=(0, 0, 0, 170))
            dd.text((wd / 2, ht / 2), word, font=f, fill=fill + (255,), anchor="mm", stroke_width=stroke, stroke_fill=(0, 0, 0, 255))
            if sf != 1.0:
                lay = lay.resize((max(2, int(wd * sf)), max(2, int(ht * sf))), Image.BILINEAR)
            parts.append(lay)
            total += lay.width + gap
        total -= gap
        maxw = self.W - 2 * self.margin_x
        scale = min(1.0, maxw / max(total, 1))
        x = (self.W - total * scale) / 2
        cy = self.H * 0.80
        for lay in parts:
            if scale < 1.0:
                lay = lay.resize((max(2, int(lay.width * scale)), max(2, int(lay.height * scale))), Image.BILINEAR)
            img.paste(lay, (int(x), int(cy - lay.height / 2)), lay)
            x += lay.width + gap * scale

    # ---------------------------------------------------------------- frame
    def frame(self, t):
        i = self.scene_at(t)
        sc = self.scenes[i]
        img = self.world(sc, t)
        if i > 0 and t - sc["start"] < TR_DUR:
            img = self.transition(self.world(self.scenes[i - 1], t), img, (t - sc["start"]) / TR_DUR, sc)
        for g in sc["_glitch"]:
            if 0 <= t - g < 0.25:
                img = glitch(img, 1.0, int(t * self.fps))
        for k, ov in enumerate(sc.get("text_overlays") or []):
            self.overlay(img, ov, sc, t, k)
        self.caption(img, t)
        return img


def render_video(spec, out_path, progress=None):
    ensure_assets()
    reel = Reel(spec)
    proj = spec.get("project") or {}
    bitrate = str(proj.get("videoBitrate", "10M"))
    abitrate = str(proj.get("audioBitrate", "192k"))
    preset = os.environ.get("FFMPEG_PRESET", "veryfast")
    work = tempfile.mkdtemp(prefix="reel_")
    try:
        wav = os.path.join(work, "mix.wav")
        build_audio(spec, reel.scenes, reel.dur, work, wav)
        cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "%dx%d" % (reel.W, reel.H),
               "-r", str(reel.fps), "-i", "-", "-i", wav, "-c:v", "libx264", "-preset", preset, "-b:v", bitrate,
               "-maxrate", bitrate, "-bufsize", "20M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", abitrate,
               "-shortest", "-movflags", "+faststart", out_path]
        errlog = open(os.path.join(work, "ffmpeg.log"), "w")
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=errlog)
        total = int(reel.dur * reel.fps)
        try:
            for n in range(total):
                frame = reel.frame(n / reel.fps)
                if frame.size != (reel.W, reel.H):
                    frame = frame.resize((reel.W, reel.H))
                proc.stdin.write(frame.tobytes())
                if progress and n % 120 == 0:
                    progress(n, total)
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()
        errlog.close()
        if proc.returncode != 0:
            raise RuntimeError("ffmpeg failed: " + open(os.path.join(work, "ffmpeg.log")).read()[-800:])
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return out_path
