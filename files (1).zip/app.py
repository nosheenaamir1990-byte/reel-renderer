"""Render endpoint for the n8n reel workflow.

POST /render  {callbackUrl, fileName, spec}  -> 202 {jobId}
The video is rendered in the background, then this service POSTs
{"videoUrl": "...", "jobId": "...", "status": "done"} to callbackUrl (the n8n Wait node resume URL).
"""
import os
import re
import threading
import time
import traceback
import uuid

import requests
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from renderer import ensure_assets, render_video

OUT_DIR = os.environ.get("OUT_DIR", "/tmp/out")
API_KEY = os.environ.get("RENDER_API_KEY", "")          # set as a Space secret; send as X-API-Key from n8n
PUBLIC_BASE = os.environ.get("PUBLIC_BASE_URL", "")      # optional override, e.g. https://user-space.hf.space
KEEP_SECONDS = 24 * 3600
os.makedirs(OUT_DIR, exist_ok=True)

app = FastAPI(title="Reel Renderer")
app.mount("/files", StaticFiles(directory=OUT_DIR), name="files")

jobs = {}
render_slot = threading.Semaphore(1)   # free CPU tier: one render at a time, extra jobs queue


class RenderRequest(BaseModel):
    callbackUrl: str
    fileName: str
    spec: dict


def public_base(request: Request):
    if PUBLIC_BASE:
        return PUBLIC_BASE.rstrip("/")
    host = os.environ.get("SPACE_HOST")                  # set automatically on Hugging Face Spaces
    if host:
        return "https://" + host
    host = request.headers.get("x-forwarded-host") or request.headers.get("host")
    return "https://" + host


def cleanup_old():
    now = time.time()
    for name in os.listdir(OUT_DIR):
        p = os.path.join(OUT_DIR, name)
        try:
            if os.path.isfile(p) and now - os.path.getmtime(p) > KEEP_SECONDS:
                os.remove(p)
        except OSError:
            pass


def post_callback(url, payload):
    for attempt in range(4):
        try:
            r = requests.post(url, json=payload, timeout=30)
            if r.status_code < 400:
                return True
            print("callback status", r.status_code, r.text[:200])
        except Exception as e:
            print("callback error", e)
        time.sleep(5 * (attempt + 1))
    return False


def worker(job_id, req: RenderRequest, base):
    job = jobs[job_id]
    with render_slot:
        job["status"] = "rendering"
        try:
            cleanup_old()
            out = os.path.join(OUT_DIR, job["fileName"])

            def progress(n, total):
                job["progress"] = round(n / total, 3)

            render_video(req.spec, out, progress)
            job.update(status="done", progress=1.0, videoUrl=base + "/files/" + job["fileName"])
            post_callback(req.callbackUrl, {"jobId": job_id, "status": "done", "videoUrl": job["videoUrl"], "fileName": job["fileName"]})
        except Exception as e:
            traceback.print_exc()
            job.update(status="error", error=str(e)[:500])
            post_callback(req.callbackUrl, {"jobId": job_id, "status": "error", "videoUrl": "", "error": job["error"]})


@app.on_event("startup")
def startup():
    threading.Thread(target=ensure_assets, daemon=True).start()


@app.get("/")
def health():
    return {"ok": True, "service": "reel-renderer", "queued_or_running": sum(1 for j in jobs.values() if j["status"] in ("queued", "rendering"))}


@app.post("/render", status_code=202)
def render(req: RenderRequest, request: Request, x_api_key: str = Header(default="")):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="bad api key")
    name = re.sub(r"[^A-Za-z0-9._-]", "_", req.fileName)[:120] or "reel.mp4"
    if not name.lower().endswith(".mp4"):
        name += ".mp4"
    job_id = uuid.uuid4().hex[:12]
    jobs[job_id] = {"status": "queued", "progress": 0.0, "fileName": name}
    threading.Thread(target=worker, args=(job_id, req, public_base(request)), daemon=True).start()
    return {"jobId": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
def job_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="unknown job")
    return jobs[job_id]
