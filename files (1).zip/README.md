---
title: Reel Renderer
emoji: 🍳
colorFrom: red
colorTo: yellow
sdk: docker
app_port: 7860
pinned: false
---

Procedural 2.5D cooking-reel renderer. POST /render with {callbackUrl, fileName, spec}.
